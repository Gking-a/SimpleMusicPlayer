package com.gkingswq.simplemusicplayer.Interface;

public interface OnGetNameCompile {
    public void onCompile(String id,String name);
}
