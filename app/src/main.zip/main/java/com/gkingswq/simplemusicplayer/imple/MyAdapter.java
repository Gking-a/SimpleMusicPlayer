package com.gkingswq.simplemusicplayer.imple;

public class MyAdapter {
    
}
